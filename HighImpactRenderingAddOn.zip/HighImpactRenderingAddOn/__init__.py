#----------------------------------------------------------
# File __init__.py
#----------------------------------------------------------
#
# The user interface is created in the "right" panel in the 3D View
# This panel is normally closed, so it must be opened (+) to be seen.
#
 
#    Addon info
bl_info = {
    "name": "High Impact Rendering Tool",
    "author": "vjvalve",
    "version": (1, 0),
    "blender": (3, 3, 0),
    "location": "View3D > Add > Mesh > New Object",
    "description": "Use precompiled C script to quickly import .ply files that have additional vertex properties and store them as vertex color attributes in the new mesh object",
    "warning": "",
    "doc_url": "",
    "category": "Add Mesh",
}

# To support reload properly, try to access a package var,
# if it's there, reload everything

modulesNames = ['importhandler', 'my_test']


# if "bpy" in locals():
#     import imp
#     imp.reload(importhandler)
#     imp.reload(my_test)
#     print("Reloaded multifiles")
# else:
#     from . import importhandler, my_test
#     print("Imported multifiles")

import bpy
# from bpy.props import *
from bpy.props import (StringProperty, PointerProperty)
from bpy.types import (Panel, Operator, PropertyGroup)

import sys
import os
import importlib

modulesFullNames = {}
for currentModuleName in modulesNames:
    modulesFullNames[currentModuleName] = ('{}.{}'.format(__name__, currentModuleName))

for currentModuleFullName in modulesFullNames.values():
    if currentModuleFullName in sys.modules:
        importlib.reload(sys.modules[currentModuleFullName])
    else:
        globals()[currentModuleFullName] = importlib.import_module(currentModuleFullName)
        setattr(globals()[currentModuleFullName], 'modulesNames', modulesFullNames)

# ------------------------------------------------------------------------
#    Scene Properties
# ------------------------------------------------------------------------

class ImportProperties(PropertyGroup):
    file_import : StringProperty(
        name="file import", 
        description=".ply file path", 
        default="", 
        maxlen=1024,
        update= lambda self, context : print("file_import changed:", self.file_import))


# ------------------------------------------------------------------------
#    Operators
# ------------------------------------------------------------------------

class OBJECT_OT_FileSearch(Operator):
    bl_label = "File Search"
    bl_idname = "wm.filesearch"
    bl_description = "Search for .ply file to import"

    filepath: StringProperty(subtype="FILE_PATH")

    # @classmethod
    # def poll(cls, context):
    #     return context.object is not None

    def execute(self, context):
        import_properties = context.scene.import_properties
        import_properties.file_import = self.filepath
        # file = open(self.filepath, 'w')
        # file.write("Hello World " + context.object.name)
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class IMPORT_OT_PLYImport(bpy.types.Operator):
    bl_label = "Import Operator"
    bl_idname = "import.fileimport"
    bl_description = "import specified .ply file"

    @classmethod
    def poll(cls, context):
        file_import_path = context.scene.import_properties.file_import
        importhandler = sys.modules[modulesFullNames['importhandler']]
        fpath = file_import_path
        fname = os.path.basename(fpath)

        return not importhandler.file_check(fname, fpath) and fname.lower().endswith('.ply')

    def execute(self, context):
        file_import_path = context.scene.import_properties.file_import
        importhandler = sys.modules[modulesFullNames['importhandler']]

        # for value in modules.keys():
        #     print("value: " + value)


        # modules['importhandler'].testing_function()
        importhandler.testing_function()

        fpath = file_import_path
        fname = os.path.basename(fpath)

        print("fname: {}, fpath: {}".format(fname, fpath))


        # fname= 'sparc-wall_with_added_properties.ply'
        # path = 'C:\\Users\\vjvalve\\Documents\\09326\\data_for_victor_2022Nov02\\surface_data\\ExtractorOutput\\'
        # fpath = path+fname
        
        # file_check(fname, fpath)
        
        importhandler.file_import_readply(fpath)
        
        self.report({"INFO"}, "filepath: {}".format(file_import_path))
        # my_test.print_testing()
        return{'FINISHED'}

# ------------------------------------------------------------------------
#    Panel in Object Mode
# ------------------------------------------------------------------------
class OBJECT_PT_HighImpactRendering(Panel):
    """Use custom importing method to import .ply file with multiple vertex properties and apply them as vertex attribute colors"""
    bl_label = "HighImpactRendering"
    bl_idname = "OBJECT_PT_HighImpactRendering"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'High Impact Rendering'

    def draw(self, context):
        import_properties = context.scene.import_properties

        layout = self.layout

        row = layout.row()
        row.label(text= "Select .ply file with vertex properties to import into the scene")

        # row.operator()
        # row.operator("mesh.primitive_cube_add")
        # row.operator("")

class OBJECT_PT_PlyImporting(Panel):
    bl_label = ".PLY Importer"
    bl_idname = "IMPORT_PT_PlyImporter"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'High Impact Rendering'
    bl_parent_id = 'OBJECT_PT_HighImpactRendering'

    def draw(self, context):
        import_properties = context.scene.import_properties

        layout = self.layout

        row = layout.row()
        row.operator("wm.filesearch", icon='FILEBROWSER', text='')
        row.prop(import_properties, "file_import", text='')

        
        row = layout.row()
        row.operator("import.fileimport", icon= 'IMPORT')
        
class OBJECT_PT_ImportRendering(Panel):
    bl_label = "Vertex Attribute Rendering"
    bl_idname = "IMPORT_PT_ImportRendering"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'High Impact Rendering'
    bl_parent_id = 'OBJECT_PT_HighImpactRendering'

    def draw(self, context):
        layout = self.layout
# ------------------------------------------------------------------------
#   Registering/Unregistering 
# ------------------------------------------------------------------------

classes = [
    OBJECT_PT_HighImpactRendering, OBJECT_OT_FileSearch, ImportProperties,OBJECT_PT_PlyImporting, IMPORT_OT_PLYImport, OBJECT_PT_ImportRendering]


def register():

    # import all files as modules and register them
    for currentModuleName in modulesFullNames.values():
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'register'):
                sys.modules[currentModuleName].register()
    
    for cls in classes:
            bpy.utils.register_class(cls)

    bpy.types.Scene.import_properties = bpy.props.PointerProperty(type=ImportProperties)

    # print ("Registering ", __name__)
    # bpy.utils.register_module(__name__)
def unregister():
    for currentModuleName in modulesFullNames.values():
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'unregister'):
                sys.modules[currentModuleName].unregister()

    for cls in classes:
        bpy.utils.unregister_class(cls)
    # print("Unregistering ", __name__)
    # bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()