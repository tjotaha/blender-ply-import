def print_testing():
    print("print testing")