import sys, os, time
try:
    import bpy, bmesh
    # from bpy.props import (StringProperty, PointerProperty, )

    # from bpy.types import (Panel, PropertyGroup)
    in_blender = True
except ImportError:
    print("Script being called outside of Blender")
    in_blender = False


sys.path.insert(0, '.')

try:
    import readply
except ImportError:
    scriptdir = os.path.split(os.path.abspath(__file__))[0]    
    sys.path.insert(0, scriptdir)
    import readply
    
# ------------------------------------------------------------------------
#    Functions
# ------------------------------------------------------------------------

def testing_function():
    print("testing_function called")
    
def unlerp(min, max, val):
    range = max - min
    diff = val - min
    return diff/range

def file_check(fname, fpath):
    print("file %s exists: %r\n" % (fname, os.path.exists(fpath)))
    
def file_import_readply(fpath):
    t0 = time.time()
    p = readply.readply(fpath)
    t1 = time.time()
    
    print('Import time %.3fs' % (t1 - t0))

    
    print(p.keys())
    print('%d vertices, %d faces' % (p['num_vertices'], p['loop_start'].shape[0]))
    
    normal_props = ["num_vertices", "num_faces", "vertices", "faces", "loop_start", "loop_length", "vertex_colors"]

    # for i in range(10):
    for key, value in p.items():
        if key not in normal_props:
            print("prop: " + key )
    #        print_property(p, key, 10, True)
            # print(p[key])


    if in_blender:
        # Create a mesh + object using the vertex and face data in the numpy arrays

        mesh = bpy.data.meshes.new(name='imported mesh')

        mesh.vertices.add(p['num_vertices'])
        mesh.vertices.foreach_set('co', p['vertices'])

        mesh.loops.add(len(p['faces']))
        mesh.loops.foreach_set('vertex_index', p['faces'])

        mesh.polygons.add(p['num_faces'])
        mesh.polygons.foreach_set('loop_start', p['loop_start'])
        mesh.polygons.foreach_set('loop_total', p['loop_length'])
        
        
        for key, value in p.items():
            if key not in normal_props:
                
                print("prop: " + key)
                prop_layer = mesh.vertex_layers_float.new(name=key)
                prop_layer.data.foreach_set('value', p[key])
                
                co_layer_prop = []
                max_d = max(p[key])
                min_d = min(p[key])
                
                i = 0
                j = 0
                k = 0
                
                if len(p[key]) < 10:
                    print("key: " + key)
                    print(*p[key])
                for vertex in p['faces']:
                    
                    prop_val = prop_layer.data[vertex].value
                    
                    unlerp_val = unlerp(min=min_d, max=max_d, val=prop_val)
                    
                    
                    unlerp_color = [unlerp_val, unlerp_val, unlerp_val, 1.0]
                    
                    co_layer_prop += unlerp_color

                pcol_layer = mesh.color_attributes.new(name=key, type="BYTE_COLOR", domain="CORNER")
                pcol_data = pcol_layer.data
                pcol_data.foreach_set("color", co_layer_prop)        
            

        if 'vertex_normals' in p:
            mesh.vertices.foreach_set('normal', p['vertex_normals'])

        if 'vertex_colors' in p:
            vcol_layer = mesh.vertex_colors.new()
            vcol_data = vcol_layer.data
            vcol_data.foreach_set('color', p['vertex_colors'])

        if 'texture_coordinates' in p:
            uv_layer = mesh.uv_layers.new(name='default')
            uv_layer.data.foreach_set('uv', p['texture_coordinates'])   

        mesh.validate()
        mesh.update()

        # Create object to link to mesh

        obj = bpy.data.objects.new('imported object', mesh)

        # Add object to the scene
        scene = bpy.context.scene
        scene.collection.children[0].objects.link(obj)

        # Select the new object and make it active
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj

        t2 = time.time()
        print('Blender object+mesh created in %.3fs' % (t2 - t1))

        del p

        print('Total import time %.3fs' % (t2 - t0))
    

# ------------------------------------------------------------------------
#    Scene Properties
# ------------------------------------------------------------------------

# class ImportProperties(PropertyGroup):
#     file_import : StringProperty(
#         name="file import", 
#         description=".ply file path", 
#         default="", 
#         maxlen=1024,
#         update= lambda self, context : print("file_import changed:", self.file_import))


# ------------------------------------------------------------------------
#    Operators
# ------------------------------------------------------------------------

# class WM_OT_PLYImport(bpy.types.Operator):
#     bl_label = "Import Operator"
#     bl_idname = "wm.fileimport"

#     def execute(self, context):
#         file_import_path = context.scene.import_properties.file_import

#         testing_function()
        
#         fname= 'sparc-wall_with_added_properties.ply'
#         path = 'C:\\Users\\vjvalve\\Documents\\09326\\data_for_victor_2022Nov02\\surface_data\\ExtractorOutput\\'
#         fpath = path+fname
        
#         file_check(fname, fpath)
        
#         file_import_readply(fpath)
        
#         self.report({"INFO"}, "filepath: {}".format(file_import_path))
#         # my_test.print_testing()
#         return{'FINISHED'}

# ------------------------------------------------------------------------
#    Panel in Object Mode
# ------------------------------------------------------------------------
# class OBJECT_PT_HighImpactRendering(bpy.types.Panel):
#     """Use custom importing method to import .ply file with multiple vertex properties and apply them as vertex attribute colors"""
#     bl_label = "HighImpactRendering"
#     bl_idname = "OBJECT_PT_HighImpactRendering"
#     bl_space_type = 'VIEW_3D'
#     bl_region_type = 'UI'
#     bl_category = 'High Impact Rendering'

#     def draw(self, context):
#         import_properties = context.scene.import_properties

#         layout = self.layout

#         row = layout.row()
#         row.prop(import_properties, "file_import")
        
#         row = layout.row()
#         row.operator("wm.fileimport", icon= 'FILEBROWSER')
        # row.operator("mesh.primitive_cube_add")
        # row.operator("")
        
# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = [
    # OBJECT_PT_HighImpactRendering, 
    # ImportProperties,
    # WM_OT_PLYImport
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls) 

    # bpy.types.Scene.import_properties = bpy.props.PointerProperty(type=ImportProperties)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()